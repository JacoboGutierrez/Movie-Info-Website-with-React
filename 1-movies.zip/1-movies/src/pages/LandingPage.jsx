import { ContextMovieCard } from "../components/ContextMovieCard"
export function LandingPage(){
    return(
        <div>
            <ContextMovieCard />
        </div>
    )
}